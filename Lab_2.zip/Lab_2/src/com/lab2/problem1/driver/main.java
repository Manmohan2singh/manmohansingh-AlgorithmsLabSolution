package com.lab2.problem1.driver;

import java.util.Scanner;
import com.lab2.problem1.transaction.Transaction;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the size of transaction array");
		int num = s.nextInt();
		int arr[] = new int[num];
		System.out.println("Enter the values of array");
		
		for(int i=0; i<num; i++)
			arr[i]=s.nextInt();
		System.out.println("Enter the total no of targets that needs to be achieved");
		int no_of_target= s.nextInt();
		
		Transaction service = new Transaction();
		service.Target(arr,no_of_target);
		s.close();
	}
}
