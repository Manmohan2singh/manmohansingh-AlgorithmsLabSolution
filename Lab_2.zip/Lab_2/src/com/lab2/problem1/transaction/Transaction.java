package com.lab2.problem1.transaction;

import java.util.Scanner;

public class Transaction {

	public static void Target(int[] args,int no_of_target) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		while(no_of_target-- != 0) {
			int flag =0;
			long target;
			System.out.println("Enter the value of target");
			target = s.nextInt();
			long sum=0;
			for(int i=0; i<args.length; i++) {
				sum +=args[i];
				if(sum>=target) {
					System.out.println("target achieved after "+(i+1)+" transaction ");
					flag=1;
					break;
				}
			}
			if(flag==0) {
				System.out.println(" Given target is not achieved ");
			}
		}
		System.out.println("Successful");
		s.close();
	}

}
