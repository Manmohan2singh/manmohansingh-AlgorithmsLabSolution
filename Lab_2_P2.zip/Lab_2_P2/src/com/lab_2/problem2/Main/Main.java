package com.lab_2.problem2.Main;

import java.util.Arrays; 
import java.util.Scanner;
import com.lab_2.problem2.pay.MergeSort;
import com.lab_2.problem2.pay.NotesCount;

public class Main {
	public static int[] arr;
	static Scanner s;
	static int amount;
	static int num;
	static MergeSort mergesort = new MergeSort();
	static NotesCount notescount = new NotesCount();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Enter the size of currency denominations");
		s = new Scanner(System.in);
		num = s.nextInt();
		System.out.println("Enter the currency denominations value");
			arr = new int[num];
			for (int i=0; i<num; i++) {
				arr[i]=s.nextInt();
			};	
		System.out.println("Enter the amount you want to pay");
		amount = s.nextInt();
		mergesort.sortArray(arr,0,arr.length-1);
		notescount.NotesCount(arr,amount);
	}
}
