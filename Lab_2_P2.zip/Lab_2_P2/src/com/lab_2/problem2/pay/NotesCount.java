package com.lab_2.problem2.pay;

public class NotesCount {

	public static void NotesCount(int[] args, int amount) {
		// TODO Auto-generated method stub
		int note[]= new int[args.length];
		
		try {
			for (int i=0; i<args.length;i++) {
				if (amount >= args[i]) {
					note[i]=amount/args[i];
					amount = amount - note[i]*args[i];
				}
			}
		if (amount>0) {
			System.out.println("We are not able to exact amount");
		}
		else {
			System.out.println("Your payment approach in order to give min no of notes will be");
			for (int i=0;i<args.length;i++) {
				if (note[i] !=0) {
					System.out.println(args[i]+":"+note[i]);
				}
			}
		}
		}
		catch(ArithmeticException e){
			System.out.println(e+" 0rs note not a valid note");
		}
	}

}
